import cv2
import numpy
import pyautogui
from PIL import (
    Image,
    ImageChops,
    ImageColor,
    ImageDraw,
    ImageFont,
    ImageGrab,
    ImageOps,
    ImageWin,
)

np = numpy
win32gui = __import__('win32gui', fromlist=('*', ), level=0)
from win32gui import *

win32con = __import__('win32con', fromlist=('*', ), level=0)
from math import cos, sin
from time import time

from win32con import *

win32api = __import__('win32api', fromlist=('*', ), level=0)
from win32api import *

win32api = __import__('win32api', fromlist=('*', ), level=0)
import matplotlib.pyplot
from win32api import *

plt = matplotlib.pyplot
import matplotlib

mpl = matplotlib
import numba
from scipy.interpolate import griddata

nb = numba

win32ui = __import__('win32ui', fromlist=('*', ), level=0)
import math
import os
import random
import sys
import time
import winsound
from random import choice, randrange
from threading import _start_new_thread

from win32ui import *

Image.MAX_IMAGE_PIXELS = None
win7 = False


def getPILScreen():
    return pyautogui.screenshot()


def toCV(img):
    open_cv_image = np.array(img.convert('RGB'))
    return open_cv_image[slice(None, None),
                         slice(None, None),
                         slice(None, None, -1)].copy()


def toPIL(img):
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))


def getMatScreen():
    return toCV(getPILScreen())


def drawPIL(hwnd, imga):
    dib = ImageWin.Dib(imga)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))


def drawMat(hwnd, img):
    I = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    res = Image.fromarray(np.uint8(I))
    dib = ImageWin.Dib(res)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))


def redraw():
    RedrawWindow(WindowFromPoint((0, 0)), None, None,
                 RDW_ALLCHILDREN | RDW_ERASE | RDW_INVALIDATE)


def drawText(hwnd,
             text,
             size,
             x,
             y,
             font='arial',
             color=None,
             stroke_width=0,
             stroke_fill=(0, 0, 0),
             canvas=False):
    if color == None:
        color = (randrange(255), randrange(255), randrange(255))
    unicode_text = 'Hello World!'
    font = ImageFont.truetype(font.lower() +
                              ('.ttf' if not font.endswith('.ttf') else ''),
                              size,
                              encoding='unic')
    (text_width, text_height) = font.getsize(unicode_text)
    canvas = getPILScreen() if not canvas else canvas
    draw = ImageDraw.Draw(canvas)
    draw.text((x, y),
              text,
              color,
              font,
              stroke_width=stroke_width,
              stroke_fill=stroke_fill)
    dib = ImageWin.Dib(canvas)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))


def chance(i):
    return random.randrange(i) == 0


x_center = int(GetSystemMetrics(0) / 2)


def GetPlotSize(size, x, y):
    return [size for i in range(len(x) * len(y))]


dc = GetDC(0)
y_center = int(GetSystemMetrics(1) / 2)
__temp_52 = BitBlt(dc, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), dc, 0,
                   0, SRCCOPY)


def EllipseWithOutline(width,
                       color=(255, 0, 0),
                       x=x_center,
                       y=y_center,
                       outline_width=5,
                       outline_color=(0, 0, 0),
                       x_add=0,
                       y_add=0):
    x += x_add
    dec = GetDC(0)
    y += y_add
    brush = CreateSolidBrush(RGB(*color))
    black_brush = CreateSolidBrush(RGB(*outline_color))
    SelectObject(dec, black_brush)
    Ellipse(dec, x - width - outline_width, y - width - outline_width,
            x + width + outline_width, y + width + outline_width)
    SelectObject(dec, brush)
    Ellipse(dec, x - width, y - width, x + width, y + width)
    DeleteObject(brush)
    DeleteObject(black_brush)


def CustomCircle(
        color=(255, 0, 0), outline_color=(0, 0, 0), out_w=5, x=0, y=0,
        add=True):
    settings = {
        'color': color,
        'outline_color': outline_color,
        'outline_width': out_w,
        'x_add' if add else 'x': x,
        'y_add' if add else 'y': y,
    }
    __temp_66 = {}
    __temp_66.update(settings)
    EllipseWithOutline(*(50, ), **__temp_66)
    __temp_69 = {}
    __temp_69.update(settings)
    EllipseWithOutline(*(40, ), **__temp_69)
    __temp_72 = {}
    __temp_72.update(settings)
    EllipseWithOutline(*(30, ), **__temp_72)
    __temp_75 = {}
    __temp_75.update(settings)
    EllipseWithOutline(*(20, ), **__temp_75)
    __temp_78 = {}
    __temp_78.update(settings)
    EllipseWithOutline(*(10, ), **__temp_78)
    __temp_81 = {}
    __temp_81.update(settings)
    EllipseWithOutline(*(1, ), **__temp_81)


def XWave(i, range=100, speed=1):
    return int(sin(i * speed) * range)


def YWave(i, range=100, speed=1):
    return int(cos(i * speed) * range)


def MosaicBlt(hwnd):
    catIm = ImageGrab.grab()
    (catImWidth, catImHeight) = catIm.size
    faceIm = catIm.resize(
        (math.floor(catImWidth / 2), math.floor(catImHeight / 2)))
    (faceImWidth, faceImHeight) = faceIm.size
    catCopyTwo = catIm.copy()
    for left in range(0, catImWidth, faceImWidth):
        for top in range(0, catImHeight, faceImHeight):
            catCopyTwo.paste(faceIm, (left, top))
            continue
        continue
    dib = ImageWin.Dib(catCopyTwo)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))


def Gs(i):
    return GetSystemMetrics(i)


def vigneteblt(hwnd,
               kernelMultiply=255,
               ex=0,
               why=0,
               start_div_x=4,
               start_div_y=4):
    x = Gs(0)
    y = Gs(1)
    im = ImageGrab.grab().convert('RGB')
    open_cv_image = np.array(im)
    img = open_cv_image[slice(None, None),
                        slice(None, None),
                        slice(None, None, -1)].copy()
    (rows, cols) = img.shape[slice(None, 2)]
    kernel_x = cv2.getGaussianKernel(cols, math.floor(x / start_div_x + ex))
    kernel_y = cv2.getGaussianKernel(rows, math.floor(y / start_div_y + why))
    kernel = kernel_y * kernel_x.T
    mask = kernelMultiply * kernel / np.linalg.norm(kernel)
    output = np.copy(img)
    for i in range(3):
        output[slice(None, None), slice(None, None),
               i] = output[slice(None, None),
                           slice(None, None), i] * mask
        continue
    drawMat(hwnd, output)


def add_vignete(pilmg,
                kernelMultiply=255,
                ex=0,
                why=0,
                start_div_x=4,
                start_div_y=4):
    x = Gs(0)
    y = Gs(1)
    im = ImageGrab.grab().convert('RGB')
    open_cv_image = np.array(im)
    img = open_cv_image[slice(None, None),
                        slice(None, None),
                        slice(None, None, -1)].copy()
    (rows, cols) = img.shape[slice(None, 2)]
    kernel_x = cv2.getGaussianKernel(cols, math.floor(x / start_div_x + ex))
    kernel_y = cv2.getGaussianKernel(rows, math.floor(y / start_div_y + why))
    kernel = kernel_y * kernel_x.T
    mask = kernelMultiply * kernel / np.linalg.norm(kernel)
    output = np.copy(img)
    for i in range(3):
        output[slice(None, None), slice(None, None),
               i] = output[slice(None, None),
                           slice(None, None), i] * mask
        continue
    return toPIL(output)


def HUE(i):
    x = 1 - abs(i / 60.0 % 2 - 1)
    i = i % 360
    if i >= 0:
        if i < 60:
            r = 1
            g = x
            b = 0
    if i >= 60:
        if i < 120:
            r = x
            g = 1
            b = 0
    if i >= 120:
        if i < 180:
            r = 0
            g = 1
            b = x
    if i >= 180:
        if i < 240:
            r = 0
            g = x
            b = 1
    if i >= 240:
        if i < 300:
            r = x
            g = 0
            b = 1
    if i >= 300:
        if i < 360:
            r = 1
            g = 0
            b = x
    res = (int(r * 255), int(g * 255), int(b * 255))
    return res


def set_size(ax, w, h):
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w) / (r - l)
    figh = float(h) / (t - b)


def rgb_split_img(img, spacing=5):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    sat = np.full(gray.shape, 100, dtype='uint8')
    blue_hue = np.full(gray.shape, 90, dtype='uint8')
    red_hue = np.full(gray.shape, 0, dtype='uint8')
    blue = cv2.merge(np.array([blue_hue, sat, gray], dtype='uint8'))
    red = cv2.merge(np.array([red_hue, sat, gray], dtype='uint8'))
    blue = cv2.cvtColor(blue, cv2.COLOR_HSV2BGR)
    red = cv2.cvtColor(red, cv2.COLOR_HSV2BGR)
    blue = imutils.translate(blue, spacing, 0)
    red = imutils.translate(red, -spacing, 0)
    np.copyto(img, blue, where=blue > img)
    np.copyto(img, red, where=red > img)
    result_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype('float32')
    (h, s, v) = cv2.split(result_hsv)
    s *= 1.5
    s = np.clip(s, 0, 255)
    v += 20
    v = np.clip(v, 0, 255)
    result_hsv = cv2.merge([h, s, v])
    result = cv2.cvtColor(result_hsv.astype('uint8'), cv2.COLOR_HSV2BGR)
    return result


def zoom_at(img, x=None, y=None, zoom=1.5):
    (w, h) = img.size
    if x == None:
        x = int(w / 2)
    if y == None:
        y = int(h / 2)
    zoom2 = zoom * 2
    img = img.crop(
        (x - w / zoom2, y - h / zoom2, x + w / zoom2, y + h / zoom2))
    return img.resize((w, h), Image.LANCZOS)


def Shake(strength, speed, seconds=5, increase=0.01):
    x = GetSystemMetrics(0)
    y = GetSystemMetrics(1)
    end = time.time() + seconds
    for i in range(345543543):
        calculatedXPos = int(np.sin(i * speed) * strength)
        calculatedYPos = int(np.cos(i * speed) * strength)
        BitBlt(dc, 0, 0, x, y, dc, calculatedXPos, calculatedYPos, SRCCOPY)
        strength += increase
        if time.time() >= end:
            break
        else:
            Sleep(10)
            continue
    return True


def invert_dc(dc):
    PatBlt(dc, 0, 0, Gs(0), Gs(1), PATINVERT)


hdc = GetDC(0)
__temp_191 = GetSystemMetrics(0)
__temp_192 = GetSystemMetrics(1)
x = __temp_191
y = __temp_192


def getCVScreen():
    return getMatScreen()


HSL = HUE
HSV = HUE


def HSVBrush(i):
    return CreateSolidBrush(RGB(*HUE(i)))


HUEBrush = HSVBrush
HSLBrush = HSVBrush


def colorize_dc(dc, black, white=(255, 255, 255)):
    drawPIL(
        dc,
        ImageOps.colorize(getPILScreen().convert('L'),
                          black=black,
                          white=white))


def colorize(img, black, white=(255, 255, 255)):
    return ImageOps.colorize(img.convert('L'), black=black, white=white)


def rotate_shake(counter, mode=SRCPAINT):
    desk = GetDC(0)
    sw = GetSystemMetrics(0)
    sh = GetSystemMetrics(1)
    deskMem = CreateCompatibleDC(desk)
    screenshot = CreateCompatibleBitmap(desk, sw, sh)
    SelectObject(deskMem, screenshot)
    wRect = list(GetWindowRect(GetDesktopWindow()))
    wPt = (
        (wRect[0] + counter, wRect[1] - counter),
        (wRect[2] + counter, wRect[1] + counter),
        (wRect[0] - counter, wRect[3] - counter),
    )
    PlgBlt(deskMem, wPt, desk, wRect[0], wRect[1], wRect[2] - wRect[0],
           wRect[3] - wRect[1], 0, 0, 0)
    BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, mode)
    Sleep(10)
    DeleteObject(screenshot)
    DeleteObject(deskMem)
    return True


def random_color():
    return choice(list(colors.__dict__.items())[slice(1, -3)])[1]


def posterise(dc):
    I = getPILScreen()
    I = ImageOps.posterize(I, 1)
    drawPIL(dc, I)


app = os.getenv('appdata')


def ResetAxisIm():
    getPILScreen().save(app + 'screen.png')


def drawAx(hwnd, ax, x, y, xrot=0, yrot=0, roth=0, redraw=True):
    ax.grid(b=None)
    ax.axis('off')
    ax.view_init(xrot, yrot)
    ax.figure.savefig(app + 'fig.png', transparent=True)
    image = Image.open(app + 'fig.png').convert('RGBA').rotate(roth)
    img = Image.open(app + 'screen.png') if redraw else getPILScreen()
    img.paste(image, (x, y), image)
    drawPIL(hwnd, img)


def pasteAx(img, ax, x, y, xrot=0, yrot=0, roth=0):
    ax.grid(b=None)
    ax.axis('off')
    ax.view_init(xrot, yrot)
    ax.figure.savefig(app + 'fig.png', transparent=True)
    image = Image.open(app + 'fig.png').convert('RGBA').rotate(roth)
    img.paste(image, (x, y), image)
    return img


__temp_246 = ResetAxisIm()


def make_interpolated_image(nsamples, im, Y, X):
    ix = np.random.randint(im.shape[1], size=nsamples)
    iy = np.random.randint(im.shape[0], size=nsamples)
    samples = im[iy, ix]
    int_im = griddata((iy, ix), samples, (Y, X))
    return int_im


def InterpolateHDC(dc, nsamples=100):

    def make_interpolated_image(nsamples):
        ix = np.random.randint(im.shape[1], size=nsamples)
        iy = np.random.randint(im.shape[0], size=nsamples)
        samples = im[iy, ix]
        int_im = griddata((iy, ix), samples, (Y, X))
        return int_im

    im = np.array(getPILScreen().convert('L'))
    nx = im.shape[1]
    ny = im.shape[0]
    (X, Y) = np.meshgrid(np.arange(0, nx, 1), np.arange(0, ny, 1))
    (nrows, ncols) = (2, 2)
    (fig, ax) = plt.subplots(nrows=2, ncols=2, figsize=(6, 4), dpi=100)
    if nx < ny:
        w = fig.get_figwidth()
        h = fig.get_figheight()
        (fig.set_figwidth(h), fig.set_figheight(w))
    get_indices = lambda i: (i // nrows, i % ncols)
    drawPIL(dc,
            Image.fromarray(make_interpolated_image(nsamples)).convert('RGB'))


def drawBlendedImg(hwnd, path, screenWeight, imgWeight, addWeighted=0):
    img1 = getCVScreen()
    img2 = path
    img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
    dst = cv2.addWeighted(img1, 0.9, img2_resized, 1, 0)
    drawMat(hwnd, dst)


def HUEShift(dc, degrees, canvas=False):
    bgr = getCVScreen()
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    (h, s, v) = cv2.split(hsv)
    hnew = np.mod(h + degrees, 180).astype(np.uint8)
    hsv_new = cv2.merge([hnew, s, v])
    bgr_new = cv2.cvtColor(hsv_new, cv2.COLOR_HSV2BGR)
    drawMat(dc, bgr_new)


def HUEShiftCanvas(dc, degrees, canvas):
    bgr = canvas
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    (h, s, v) = cv2.split(hsv)
    hnew = np.mod(h + degrees, 180).astype(np.uint8)
    hsv_new = cv2.merge([hnew, s, v])
    bgr_new = cv2.cvtColor(hsv_new, cv2.COLOR_HSV2BGR)
    drawMat(dc, bgr_new)


def HUEShiftPIL(im, degrees):
    bgr = toCV(im)
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    (h, s, v) = cv2.split(hsv)
    hnew = np.mod(h + degrees, 180).astype(np.uint8)
    hsv_new = cv2.merge([hnew, s, v])
    return toPIL(cv2.cvtColor(hsv_new, cv2.COLOR_HSV2BGR))


def EnumerateMsgBoxesCallback(hwnd, lParam):
    try:
        buffering = PyMakeBuffer(255)
        length = SendMessage(hwnd, WM_GETTEXT, 255, buffering)
        result = str(buffering[slice(0,
                                     length * 2)].tobytes().decode('utf-16'))
        if result == '&Yes':
            SendMessage(hwnd, WM_SETTEXT, None, mg1)
        if result == '&No':
            SendMessage(hwnd, WM_SETTEXT, None, mg2)
            return False
        if result == 'Cancel':
            SendMessage(hwnd, WM_SETTEXT, None, mg3)
            return False
        if result == 'OK':
            SendMessage(hwnd, WM_SETTEXT, None, mg1)
            return False
    except:
        return


def EnumerateMsgBoxes(msg1, msg2=None, msg3=None):
    global mg1, mg3, mg2
    mg1 = msg1
    mg2 = msg2
    mg3 = msg3
    Sleep(200)
    EnumChildWindows(GetDesktopWindow(), EnumerateMsgBoxesCallback, None)


def CustomMessageBox(desc, title, icons, button1, button2=None, button3=None):
    dcwin = GetDesktopWindow()
    buttons = MB_OK if button2 == None else MB_YESNO if button3 == None else MB_YESNOCANCEL
    r = buttons if icons == None else buttons | icons
    _start_new_thread(EnumerateMsgBoxes, (button1, button2))
    return MessageBox(desc, title, r)


def DrawHueText(dc, text, l=False):
    Sleep(10)
    if l:
        text = choice(text)
    drawText(dc,
             text,
             randint(10, 70),
             randint(0, x - 70),
             randint(0, y - 70),
             color=HUE(round(time.time() * 100 + 180)),
             stroke_width=1)


def CustomThread():
    __module__ = __name__
    __qualname__ = 'CustomThread'

    def __init__(self, func, args=[]):
        self.args = tuple(args)
        self.func = func
        self.latency = False
        self.is_running = False

    def __call__(self):
        self.is_running = True
        _start_new_thread(self.thread_executor, tuple([]))
        print('[Debug] [Gdi] [INFO] Thread ' +
              str(str(self.func).split(' ')[slice(1, -2)][0]) +
              ' is starting...')

    def thread_executor(self):
        print('[Debug] [Gdi] [SUCCESS] Thread ' +
              str(str(self.func).split(' ')[slice(1, -2)][0]) + ' started!')
        if self.is_running:
            self.func(*self.args)
        self.latency = time.time() - self.r_time

    def __del__(self):
        self.terminate(True)

    def terminate(self, is_del=False):
        if self.is_running:
            self.is_running = False
            self.r_time = time.time()
            print('[Debug] [Gdi] [INFO] Waiting for termination of ' +
                  str(str(self.func).split(' ')[slice(1, -2)][0]) + '...')
            if not self.latency:
                time.sleep(0.01)
                if not time.time() - self.r_time >= 1.5:
                    pass
                if not self.r_time <= 1.54:
                    pass
                print('[Debug] [Gdi] [WARNING] Long termination detected! (' +
                      str(str(self.func).split(' ')[slice(1, -2)][0]) + ')')
            print(
                '[Debug] [Gdi] [SUCCESS] Termination response loaded from thread '
                + str(str(self.func).split(' ')[slice(1, -2)][0]) +
                ', after ' + str(round(self.latency * 1000)) + ' ms!')
            if is_del:
                print(
                    '[Debug] [Gdi] [WARNING] Thread ' +
                    str(str(self.func).split(' ')[slice(1, -2)][0]) +
                    ' was automatically closed. Consider closing it manually using thread.terminate()'
                )
            return
        else:
            if not is_del:
                print(
                    '[Debug] [Gdi] [WARNING] Duplicate termination detected! ('
                    + str(str(self.func).split(' ')[slice(1, -2)][0]) + ')')
            return


CustomThread = __build_class__(CustomThread, 'CustomThread', object)


def VoxelShape():

    def gen_voxel(x):
        sl = ()
        for i in range(x.ndim):
            x = (x[sl + np.index_exp[slice(None, -1)]] +
                 x[sl + np.index_exp[slice(1, None)]]) / 2
            sl += np.index_exp[slice(None, None)]
            continue
        return x

    (r, g, b) = np.indices((17, 17, 17)) / 16.0
    rc = gen_voxel(r)
    gc = gen_voxel(g)
    bc = gen_voxel(b)
    sphere = (rc - 0.5)**2 + (gc - 0.5)**2 + (bc - 0.5)**2 < 0.25
    colors = np.zeros(sphere.shape + (3, ))
    colors[Ellipsis, 0] = rc
    colors[Ellipsis, 1] = gc
    colors[Ellipsis, 2] = bc
    ax = plt.figure().add_subplot(projection='3d')
    ax.voxels(r,
              g,
              b,
              sphere,
              facecolors=colors,
              edgecolors=np.clip(2 * colors - 0.5, 0, 1),
              linewidth=0.5)
    return ax


def VoxelCube(r, g, b):
    __temp_405 = []
    __temp_405.extend((1, 1, 1))
    colors = np.empty(__temp_405 + [4], dtype=np.float32)
    colors[slice(None, None)] = [
        0.00392156862745098 * r, 0.00392156862745098 * g,
        0.00392156862745098 * b, 1
    ]
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    __temp_412 = []
    __temp_412.extend((1, 1, 1))
    ax.voxels(np.ones(__temp_412, dtype=bool), facecolors=colors)
    return ax


color_table = []
prev_gamma = 1.0
__temp_416 = range(128, 256)
for i in __temp_416:
    __temp_418 = color_table.extend([i, i])
    continue


def applyColorFilter(image, channels_indexes):
    output_image = image.copy()
    for channel_index in channels_indexes:
        output_image[slice(None, None),
                     slice(None, None), channel_index] = cv2.LUT(
                         output_image[slice(None, None),
                                      slice(None, None), channel_index],
                         np.array(color_table).astype('uint8'))
        continue
    return output_image


def changeIntensity(image, scale_factor, channels_indexes):
    global prev_gamma, intensity_table
    output_image = image.copy()
    gamma = 1.0 / scale_factor
    if gamma != prev_gamma:
        intensity_table = []
        for i in range(256):
            intensity_table.append(
                np.clip(a=pow(i / 255.0, gamma) * 255.0, a_min=0, a_max=255))
            continue
        prev_gamma = gamma
    for channel_index in channels_indexes:
        output_image[slice(None, None),
                     slice(None, None), channel_index] = cv2.LUT(
                         output_image[slice(None, None),
                                      slice(None, None), channel_index],
                         np.array(intensity_table).astype('uint8'))
        continue
    return output_image


def playsound(name):
    winsound.PlaySound(name, winsound.SND_ASYNC | winsound.SND_ALIAS)


def path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath('.') + os.sep + 'include'
    return os.path.join(base_path, relative_path)


def DrawBack():
    __module__ = __name__
    __qualname__ = 'DrawBack'

    def PIL(func):

        def callback(*args, **kwargs):
            args = list(args)
            draw = kwargs['draw'] if 'draw' in kwargs else True
            kwargs.pop('draw', None)
            if draw:
                dc = args[0]
                args.pop(0)
            else:
                dc = False
            args = args[slice(int(not dc), None)]
            if 'img' in kwargs:
                i = kwargs['img']
                del kwargs['img']
            else:
                i = getPILScreen()
            __temp_440 = [i]
            __temp_440.extend(args)
            __temp_442 = {}
            __temp_442.update(kwargs)
            res = func(*tuple(__temp_440), **__temp_442)
            if draw:
                drawPIL(dc, res)
            return res

        return callback


DrawBack = __build_class__(DrawBack, 'DrawBack', object)


def _random_walk(length, max_step_length):
    output = []
    pos = 0
    for _ in range(length):
        pos += random.randint(-max_step_length, max_step_length)
        output.append(pos)
        continue
    return output


def _get_grid_boxes(im, rows, cols):
    cell_width = int(im.size[0] / cols)
    cell_height = int(im.size[1] / rows)

    def __temp_454(comp_arg_0):
        __temp_456 = []
        for __temp_457 in comp_arg_0:
            cell_y = __temp_457
            for __temp_459 in iter(range(cols)):
                cell_x = __temp_459
                __temp_456.append((cell_x * cell_width, cell_y * cell_height,
                                   cell_x * cell_width + cell_width,
                                   cell_y * cell_height + cell_height))
                continue
            continue
        return __temp_456

    return __temp_454(iter(range(rows)))


def PuzzleUp(dc):
    for i in range(20):
        Glitches.SwapBlocks(dc, 6, 6, 4)
        continue


def make_noise_data(length, min, max):
    return [
        ImageColor.getrgb(f'hsl(0, 0%, {random.randint(min, max)}%)')
        for _ in range(length)
    ]


def _split_data(data, width):
    height = int(len(data) / width)
    return [
        data[slice(row * width, row * width + width)] for row in range(height)
    ]


def mask_default(x):
    if x < 100:
        return 255
    return 0


def _get_lum(rgb):
    return int(0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2])


def Glitches():
    __module__ = __name__
    __qualname__ = 'Glitches'

    def RgbSplit(im, x, y=0):
        bands = list(im.split())
        bands[0] = ImageChops.offset(bands[0], x, y)
        bands[2] = ImageChops.offset(bands[2], -x, -y)
        merged = Image.merge(im.mode, bands)
        return merged

    RgbSplit = DrawBack.PIL(RgbSplit)
    {'offset': int}

    def RgbSplit_Direction(im, direction, offset=5):
        bands = list(im.split())
        dir = math.radians(direction)
        x1 = math.sin(dir) * offset
        y1 = math.cos(dir) * offset
        x2 = -x1
        y2 = -y1
        bands[0] = ImageChops.offset(bands[0], int(x1), int(y1))
        bands[2] = ImageChops.offset(bands[2], int(x2), int(y2))
        merged = Image.merge(im.mode, bands)
        return merged

    RgbSplit_Direction = DrawBack.PIL(RgbSplit_Direction)
    {'offset_mag': int, 'coverage': float}

    def Corrupt(im, offset_mag, coverage):
        corrupted = im
        line_count = int(im.size[1] * coverage)
        for ypos in random.choices(range(im.size[1]), k=line_count):
            box = (0, ypos, corrupted.size[0], ypos + 1)
            line = corrupted.crop(box)
            offset = random.randint(-offset_mag, offset_mag)
            line = ImageChops.offset(line, offset, 0)
            corrupted.paste(line, box=box)
            continue
        return corrupted

    Corrupt = DrawBack.PIL(Corrupt)

    def Walk(im, max_step_length):
        waved = im
        curve = _random_walk(im.size[1], max_step_length)
        for ypos in range(im.size[1]):
            box = (0, ypos, waved.size[0], ypos + 1)
            line = waved.crop(box)
            offset = curve[ypos]
            line = ImageChops.offset(line, offset, 0)
            waved.paste(line, box=box)
            continue
        return waved

    Walk = DrawBack.PIL(Walk)

    def SineWave(im, mag, freq, phase=0):
        waved = im
        for ypos in range(im.size[1]):
            box = (0, ypos, waved.size[0], ypos + 1)
            line = waved.crop(box)
            offset = int(mag * math.sin(2 * math.pi * freq *
                                        (ypos / im.size[1]) + phase))
            line = ImageChops.offset(line, offset, 0)
            waved.paste(line, box=box)
            continue
        return waved

    SineWave = DrawBack.PIL(SineWave)
    {'rows': int, 'cols': int, 'swaps': int}

    def SwapBlocks(modified, rows, cols, swaps):
        grid_boxes = _get_grid_boxes(modified, rows, cols)
        chosen_boxes = random.choices(grid_boxes, k=swaps * 2)
        box_pairs = [(chosen_boxes[2 * i], chosen_boxes[2 * i + 1])
                     for i in range(int(len(chosen_boxes) / 2))]
        for (box1, box2) in box_pairs:
            cell1 = modified.crop(box1)
            cell2 = modified.crop(box2)
            modified.paste(cell1, box2)
            modified.paste(cell2, box1)
            continue
        return modified

    SwapBlocks = DrawBack.PIL(SwapBlocks)
    {'rows': int, 'cols': int, 'cells': int}

    def NoiseBlocks(im, rows, cols, cells):
        modified = im
        grid_boxes = _get_grid_boxes(modified, rows, cols)
        chosen_boxes = random.choices(grid_boxes, k=cells)
        for box in chosen_boxes:
            noise_cell = Image.new(modified.mode,
                                   (box[2] - box[0], box[3] - box[1]))
            noise_cell.putdata(
                make_noise_data(noise_cell.size[0] * noise_cell.size[1], 0,
                                75))
            modified.paste(ImageChops.lighter(modified.crop(box), noise_cell),
                           box)
            continue
        return modified

    NoiseBlocks = DrawBack.PIL(NoiseBlocks)
    {'count': int, 'thickness': int}

    def NoiseLines(im, count, thickness):
        modified = im.convert('RGBA')
        boxes = [(0, ypos, im.size[0], ypos + random.randint(1, thickness))
                 for ypos in random.choices(range(im.size[1]), k=count)]
        for box in boxes:
            noise_cell = Image.new(modified.mode,
                                   (box[2] - box[0], box[3] - box[1]))
            noise_cell.putdata(
                make_noise_data(noise_cell.size[0] * noise_cell.size[1], 0,
                                75))
            combined_cell = ImageChops.lighter(modified.crop(box), noise_cell)
            combined_cell.putalpha(128)
            modified.alpha_composite(combined_cell, (box[0], box[1]))
            continue
        return modified.convert(im.mode)

    NoiseLines = DrawBack.PIL(NoiseLines)
    {'reverse': bool}

    def PixelSort(im, mask_function, reverse=False):
        interval_mask = im.convert('L').point(mask_function)
        interval_mask_data = list(interval_mask.getdata())
        interval_mask_row_data = _split_data(interval_mask_data, im.size[0])
        interval_boxes = []
        for (row_index, row_data) in enumerate(interval_mask_row_data):
            for (pixel_index, pixel) in enumerate(row_data):
                if pixel_index == 0:
                    if pixel == 255:
                        start = (pixel_index, row_index)
                        continue
                if pixel == 255:
                    if row_data[pixel_index - 1] == 0:
                        start = (pixel_index, row_index)
                        continue
                if pixel_index == len(row_data) - 1:
                    if pixel == 255:
                        end = (pixel_index, row_index + 1)
                        interval_boxes.append(
                            (start[0], start[1], end[0], end[1]))
                        continue
                if not pixel == 0:
                    continue
                if not pixel_index > 0:
                    continue
                if not row_data[pixel_index - 1] == 255:
                    continue
                end = (pixel_index, row_index + 1)
                interval_boxes.append((start[0], start[1], end[0], end[1]))
                continue
            continue
        modified = im
        for box in interval_boxes:
            cropped_interval = modified.crop(box)
            interval_data = list(cropped_interval.getdata())
            cropped_interval.putdata(
                sorted(interval_data, key=_get_lum, reverse=reverse))
            modified.paste(cropped_interval, box=(box[0], box[1]))
            continue
        return modified

    PixelSort = DrawBack.PIL(PixelSort)


Glitches = __build_class__(Glitches, 'Glitches')


def RGBTurn(speed):
    for i in range(int(360 / speed)):
        Glitches.RgbSplit_Direction(dc, i * speed)
        continue


def GetPILFromDC(wDC, w, h):
    dc = CreateDCFromHandle(wDC)
    cDC = dc.CreateCompatibleDC()
    bmp = CreateBitmap()
    bmp.CreateCompatibleBitmap(dc, w, h)
    cDC.SelectObject(bmp)
    cDC.BitBlt((0, 0), (w, h), dc, (0, 0), SRCCOPY)
    signedInts = np.fromstring(bmp.GetBitmapBits(True), dtype='uint8')
    signedInts.shape = (h, w, 4)
    return Image.fromarray(signedInts).resize((w * 4, h * 4))


def ChopScreen(img, x, y):
    return ImageChops.offset(img, x, y)


ChopScreen = DrawBack.PIL(ChopScreen)


def Screen():
    __module__ = __name__
    __qualname__ = 'Screen'

    def convert(mode):
        drawPIL(dc, getPILScreen().convert(mode).convert('RGB'))

    def rotate(*args, **kwargs):
        __temp_602 = {}
        __temp_602.update(kwargs)
        drawPIL(dc, getPILScreen().rotate(*args, **__temp_602))


Screen = __build_class__(Screen, 'Screen')


def RGBSplitImgDir(im, direction, offset=5):
    bands = list(im.split())
    dir = math.radians(direction)
    x1 = math.sin(dir) * offset
    y1 = math.cos(dir) * offset
    x2 = -x1
    y2 = -y1
    bands[0] = ImageChops.offset(bands[0], int(x1), int(y1))
    bands[2] = ImageChops.offset(bands[2], int(x2), int(y2))
    merged = Image.merge(im.mode, bands)
    return merged


def SineImg(im, mag, freq, phase=0):
    waved = im
    for ypos in range(im.size[1]):
        box = (0, ypos, waved.size[0], ypos + 1)
        line = waved.crop(box)
        offset = int(mag * math.sin(2 * math.pi * freq *
                                    (ypos / im.size[1]) + phase))
        line = ImageChops.offset(line, offset, 0)
        waved.paste(line, box=box)
        continue
    return waved


def GenerateGlitch():
    ia = Image.open(path('gli.jpg')).resize(getPILScreen().size).rotate(
        180 * randrange(3))
    ir = ia if randrange(2) == 1 else ImageOps.flip(ia)
    return HUEShiftPIL(
        random.choice([
            lambda x: SineImg(x, randrange(10), randrange(10)),
            lambda i: RGBSplitImgDir(i,
                                     randrange(10) + 1)
        ])(ir), randrange(360))


def GetIterablePixels(im):
    i = im.load()

    def __temp_645(comp_arg_0):
        __temp_647 = []
        for __temp_648 in comp_arg_0:
            x = __temp_648
            for __temp_650 in iter(range(im.size[1])):
                y = __temp_650
                __temp_647.append((i[x, y], x, y))
                continue
            continue
        return __temp_647

    return __temp_645(iter(range(im.size[0])))


def sin(a, m=1):
    return int(np.sin(i) * m)


def cos(a, m=1):
    return int(np.cos(i) * m)


def HUEify(dc, callback=lambda x, y, intensity: x + y + intensity):
    im = getPILScreen()
    data = []
    for (pixel, x, y) in GetIterablePixels(im):
        intensity = sum(pixel)
        im.putpixel((x, y),
                    HUE(
                        callback(*[x, y, intensity][slice(
                            None, callback.__code__.co_argcount)])))
        continue
    drawPIL(dc, im)


def HorizontalWave(dc, mag, freq):
    drawPIL(
        dc,
        Glitches.SineWave(dc,
                          mag,
                          freq,
                          img=getPILScreen().rotate(90, expand=True),
                          draw=False).rotate(270, expand=True))


def VerticalWave(dc, mag, freq):
    drawPIL(
        dc,
        Glitches.SineWave(dc,
                          mag,
                          freq,
                          img=getPILScreen().rotate(180, expand=True),
                          draw=False).rotate(180, expand=True))


def NerdyMath():
    __module__ = __name__
    __qualname__ = 'NerdyMath'
    pi = 3.141592653589793

    def deg_to_radians(deg):
        return deg * (NerdyMath.pi / 180)


NerdyMath = __build_class__(NerdyMath, 'NerdyMath')


def Callbacks():
    __module__ = __name__
    __qualname__ = 'Callbacks'

    def HUE():
        __module__ = __name__
        __qualname__ = 'Callbacks.HUE'
        vertical_only = lambda x, y: y
        vertical = lambda x, y, intensity: y + intensity
        horizontal_only = lambda x: x
        horizontal = lambda x, y, intensity: x + intensity
        sicksack_only = lambda x, y: x + y
        sicksack = lambda x, y, intensity: x + y + intensity

        def directional(dir):
            radians = NerdyMath.deg_to_radians(dir)
            print(radians)
            dx = np.sin(radians)
            dy = np.cos(radians)
            func = lambda x, y, intensity: x * dx + y * dy + intensity
            return func

        def directional_only(dir):
            radians = NerdyMath.deg_to_radians(dir)
            print(radians)
            dx = np.sin(radians)
            dy = np.cos(radians)
            func = lambda x, y, intensity: x * dx + y * dy
            return func

    HUE = __build_class__(HUE, 'HUE')


Callbacks = __build_class__(Callbacks, 'Callbacks')
__temp_696 = nb.njit(parallel=True)


def rainbow_directional(img, a=0):
    intensity = img.sum(axis=-1)
    (row, col) = img.shape[slice(None, 2)]
    for r in nb.prange(row):
        for c in nb.prange(col):
            i = intensity[r, c] + r + c + a
            x = 1 - abs(i / 60 % 2 - 1)
            i %= 360
            res = np.zeros(3)
            if i >= 0:
                if i < 60:
                    res = np.array([1, x, 0])
                elif i >= 60:
                    if i < 120:
                        res = np.array([x, 1, 0])
                    elif i >= 120:
                        if i < 180:
                            res = np.array([0, 1, x])
                        elif i >= 180:
                            if i < 240:
                                res = np.array([0, x, 1])
                            elif i >= 240:
                                if i < 300:
                                    res = np.array([x, 0, 1])
                                elif i >= 300:
                                    if i < 360:
                                        res = np.array([1, 0, x])
                            elif i >= 300:
                                if i < 360:
                                    res = np.array([1, 0, x])
                        elif i >= 240:
                            if i < 300:
                                res = np.array([x, 0, 1])
                            elif i >= 300:
                                if i < 360:
                                    res = np.array([1, 0, x])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 180:
                        if i < 240:
                            res = np.array([0, x, 1])
                        elif i >= 240:
                            if i < 300:
                                res = np.array([x, 0, 1])
                            elif i >= 300:
                                if i < 360:
                                    res = np.array([1, 0, x])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 240:
                        if i < 300:
                            res = np.array([x, 0, 1])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 120:
                    if i < 180:
                        res = np.array([0, 1, x])
                    elif i >= 180:
                        if i < 240:
                            res = np.array([0, x, 1])
                        elif i >= 240:
                            if i < 300:
                                res = np.array([x, 0, 1])
                            elif i >= 300:
                                if i < 360:
                                    res = np.array([1, 0, x])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 240:
                        if i < 300:
                            res = np.array([x, 0, 1])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 180:
                    if i < 240:
                        res = np.array([0, x, 1])
                    elif i >= 240:
                        if i < 300:
                            res = np.array([x, 0, 1])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 240:
                    if i < 300:
                        res = np.array([x, 0, 1])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 300:
                    if i < 360:
                        res = np.array([1, 0, x])
            elif i >= 60:
                if i < 120:
                    res = np.array([x, 1, 0])
                elif i >= 120:
                    if i < 180:
                        res = np.array([0, 1, x])
                    elif i >= 180:
                        if i < 240:
                            res = np.array([0, x, 1])
                        elif i >= 240:
                            if i < 300:
                                res = np.array([x, 0, 1])
                            elif i >= 300:
                                if i < 360:
                                    res = np.array([1, 0, x])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 240:
                        if i < 300:
                            res = np.array([x, 0, 1])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 180:
                    if i < 240:
                        res = np.array([0, x, 1])
                    elif i >= 240:
                        if i < 300:
                            res = np.array([x, 0, 1])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 240:
                    if i < 300:
                        res = np.array([x, 0, 1])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 300:
                    if i < 360:
                        res = np.array([1, 0, x])
            elif i >= 120:
                if i < 180:
                    res = np.array([0, 1, x])
                elif i >= 180:
                    if i < 240:
                        res = np.array([0, x, 1])
                    elif i >= 240:
                        if i < 300:
                            res = np.array([x, 0, 1])
                        elif i >= 300:
                            if i < 360:
                                res = np.array([1, 0, x])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 240:
                    if i < 300:
                        res = np.array([x, 0, 1])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 300:
                    if i < 360:
                        res = np.array([1, 0, x])
            elif i >= 180:
                if i < 240:
                    res = np.array([0, x, 1])
                elif i >= 240:
                    if i < 300:
                        res = np.array([x, 0, 1])
                    elif i >= 300:
                        if i < 360:
                            res = np.array([1, 0, x])
                elif i >= 300:
                    if i < 360:
                        res = np.array([1, 0, x])
            elif i >= 240:
                if i < 300:
                    res = np.array([x, 0, 1])
                elif i >= 300:
                    if i < 360:
                        res = np.array([1, 0, x])
            elif i >= 300:
                if i < 360:
                    res = np.array([1, 0, x])
            img[r, c] = res * 255
            continue
        continue
    return img


rainbow_directional = __temp_696(rainbow_directional)


def RainbowEffects():
    __module__ = __name__
    __qualname__ = 'RainbowEffects'

    def x(img):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r + intensity[r, c]
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    x = nb.njit(parallel=True)(x)

    def y(img):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = c + intensity[r, c]
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    y = nb.njit(parallel=True)(y)

    def sicksack(img, a=0):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r + c + intensity[r, c] + a
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    sicksack = nb.njit(parallel=True)(sicksack)

    def xor(img):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r ^ c + intensity[r, c]
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    xor = nb.njit(parallel=True)(xor)

    def xor_only(img):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r ^ c
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    xor_only = nb.njit(parallel=True)(xor_only)

    def pow(img):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r**c + intensity[r, c]
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    pow = nb.njit(parallel=True)(pow)

    def circle(img, density=500, radius=10):
        intensity = img.sum(axis=-1)
        (row, col) = img.shape[slice(None, 2)]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = math.sin(c / radius) * density + math.cos(
                    r / radius) * density
                x = 1 - abs(i / 60 % 2 - 1)
                x = int(x * 255)
                i %= 360
                if i < 180:
                    if i < 60:
                        res[r, c, 0] = 255
                        res[r, c, 1] = x
                    elif i < 120:
                        res[r, c, 0] = x
                        res[r, c, 1] = 255
                    else:
                        res[r, c, 1] = 255
                        res[r, c, 2] = x
                    continue
                if i < 240:
                    res[r, c, 1] = x
                    res[r, c, 2] = 255
                    continue
                if i < 300:
                    res[r, c, 0] = x
                    res[r, c, 2] = 255
                    continue
                res[r, c, 0] = 255
                res[r, c, 2] = x
                continue
            continue
        return res

    circle = nb.njit(parallel=True)(circle)


RainbowEffects = __build_class__(RainbowEffects, 'RainbowEffects')


def effects():
    __module__ = __name__
    __qualname__ = 'effects'

    def HUE():
        __module__ = __name__
        __qualname__ = 'effects.HUE'

        def x(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.x(ie))
            drawPIL(dc, rf)

        def y(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.y(ie))
            drawPIL(dc, rf)

        def sicksack(dc, a=0):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.sicksack(ie, a))
            drawPIL(dc, rf)

        def xor(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.xor(ie))
            drawPIL(dc, rf)

        def xor_only(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.xor_only(ie))
            drawPIL(dc, rf)
            return rf

        def pow(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.pow(ie))
            drawPIL(dc, rf)

        def circle(dc, density=500, radius=10):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.circle(ie, density, radius))
            drawPIL(dc, rf)

    HUE = __build_class__(HUE, 'HUE')

    def compile():
        funcs = [
            effects.HUE.x,
            effects.HUE.y,
            effects.HUE.sicksack,
            effects.HUE.xor,
            effects.HUE.xor_only,
            effects.HUE.pow,
        ]
        for f in funcs:
            f(0)
            continue


effects = __build_class__(effects, 'effects')
