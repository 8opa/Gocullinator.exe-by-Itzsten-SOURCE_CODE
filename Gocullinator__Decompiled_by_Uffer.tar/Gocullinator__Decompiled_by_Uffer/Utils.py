from PIL import ImageWin, Image, ImageGrab, ImageOps, ImageDraw, ImageFilter, ImageEnhance, ImageFont, ImageChops, ImageColor
import cv2
import pyautogui
import numpy as np
from win32gui import *
from win32con import *
from time import time
from math import cos, sin
from win32api import *
from win32api import *
import matplotlib.pyplot as plt
import matplotlib as mpl
from scipy.interpolate import griddata
import numba as nb
from mpl_toolkits.mplot3d import Axes3D
from win32ui import *
import os
import winsound
import sys
from random import randrange
import time
from threading import _start_new_thread
import math
import random
from random import choice
from random import randint as rand
Image.MAX_IMAGE_PIXELS = None
win7 = False

def getPILScreen():
    return pyautogui.screenshot()

def toCV(img):
    open_cv_image = np.array(img.convert("RGB"))
    return open_cv_image[([:], [:], [:])].copy()

def toPIL(img):
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

def getMatScreen():
    return toCV(getPILScreen())

def drawPIL(hwnd, imga):
    dib = ImageWin.Dib(imga)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))

def drawMat(hwnd, img):
    I = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    res = Image.fromarray(np.uint8(I))
    dib = ImageWin.Dib(res)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))

def redraw():
    RedrawWindow(WindowFromPoint((0, 0)), None, None, RDW_ALLCHILDREN | RDW_ERASE | RDW_INVALIDATE)

def drawText(hwnd, text, size, x, y, font="arial", color=None, stroke_width=0, stroke_fill=(0, 0, 0), canvas=False):
    if color == None:
        color = (randrange(255), randrange(255), randrange(255))
        unicode_text = "Hello World!"
    font = ImageFont.truetype(font.lower() if not font.endswith(".ttf") else ".ttf" + "", size, encoding="unic")
    text_width, text_height = font.getsize(unicode_text)
    if not canvas:
        pass
    else:
        canvas = canvas
    draw = ImageDraw.Draw(canvas)
    draw.text((x, y), text, color, font, stroke_width=stroke_width, stroke_fill=stroke_fill)
    dib = ImageWin.Dib(canvas)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))

def chance(i: int):
    return random.randrange(i) == 0

x_center = int(GetSystemMetrics(0) / 2)
def GetPlotSize(size, x, y):
    return [size for i in range(len(x) * len(y))]

dc = GetDC(0)
y_center = int(GetSystemMetrics(1) / 2)
BitBlt(dc, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), dc, 0, 0, SRCCOPY)
def EllipseWithOutline(width, color=(255, 0, 0), x=x_center, y=y_center, outline_width=5, outline_color=(0, 0, 0), x_add=0, y_add=0):
    x += x_add
    dec = GetDC(0)
    y += y_add
    brush = CreateSolidBrush(RGB(*color))
    black_brush = CreateSolidBrush(RGB(*outline_color))
    SelectObject(dec, black_brush)
    Ellipse(dec, x - width - outline_width, y - width - outline_width, x + width + outline_width, y + width + outline_width)
    SelectObject(dec, brush)
    Ellipse(dec, x - width, y - width, x + width, y + width)
    DeleteObject(brush)
    DeleteObject(black_brush)

def CustomCircle(color=(255, 0, 0), outline_color=(0, 0, 0), out_w=5, x=0, y=0, add=True):
    settings = {"color": color, "outline_color": outline_color, "outline_width": out_w, "x_add": "x" if add else x, "y_add": "y" if add else y}
    EllipseWithOutline(*(50))
    EllipseWithOutline(*(40))
    EllipseWithOutline(*(30))
    EllipseWithOutline(*(20))
    EllipseWithOutline(*(10))
    EllipseWithOutline(*(1))

def XWave(i, range=100, speed=1):
    return int(sin(i * speed) * range)

def YWave(i, range=100, speed=1):
    return int(cos(i * speed) * range)

def MosaicBlt(hwnd):
    catIm = ImageGrab.grab()
    catImWidth, catImHeight = catIm.size
    faceIm = catIm.resize((math.floor(catImWidth / 2), math.floor(catImHeight / 2)))
    faceImWidth, faceImHeight = faceIm.size
    catCopyTwo = catIm.copy()
    
    for left in range(0, catImWidth, faceImWidth):
        for top in range(0, catImHeight, faceImHeight):
            catCopyTwo.paste(faceIm, (left, top))
    dib = ImageWin.Dib(catCopyTwo)
    dib.draw(hwnd, (0, 0, GetSystemMetrics(0), GetSystemMetrics(1)))

def Gs(i):
    return GetSystemMetrics(i)

def vigneteblt(hwnd, kernelMultiply=255, ex=0, why=0, start_div_x=4, start_div_y=4):
    x = Gs(0)
    y = Gs(1)
    im = ImageGrab.grab().convert("RGB")
    open_cv_image = np.array(im)
    img = open_cv_image[([:], [:], [:])].copy()
    rows, cols = img.shape[:2]
    kernel_x = cv2.getGaussianKernel(cols, math.floor(x / start_div_x + ex))
    kernel_y = cv2.getGaussianKernel(rows, math.floor(y / start_div_y + why))
    kernel = kernel_y * (kernel_x.T)
    mask = kernelMultiply * kernel / np.linalg.norm(kernel)
    output = np.copy(img)
    for i in range(3):
        output[([:], [:],
            i)] = output[([:], [:],
    i)] * mask
    drawMat(hwnd, output)

def add_vignete(pilmg, kernelMultiply=255, ex=0, why=0, start_div_x=4, start_div_y=4):
    x = Gs(0)
    y = Gs(1)
    im = ImageGrab.grab().convert("RGB")
    open_cv_image = np.array(im)
    img = open_cv_image[([:], [:], [:])].copy()
    rows, cols = img.shape[:2]
    kernel_x = cv2.getGaussianKernel(cols, math.floor(x / start_div_x + ex))
    kernel_y = cv2.getGaussianKernel(rows, math.floor(y / start_div_y + why))
    kernel = kernel_y * (kernel_x.T)
    mask = kernelMultiply * kernel / np.linalg.norm(kernel)
    output = np.copy(img)
    for i in range(3):
        output[([:], [:],
            i)] = output[([:], [:],
    i)] * mask
    
    return toPIL(output)

def HUE(i):
    x = 1 - abs(i / 60.0 % 2 - 1)
    i = i % 360
    if i >= 0 and i < 60:
        r = 1
        g = x
        b = 0
        if i >= 60 and i < 120:
            r = x
            g = 1
            b = 0
            if i >= 120 and i < 180:
                r = 0
                g = 1
                b = x
                if i >= 180 and i < 240:
                    r = 0
                    g = x
                    b = 1
                    if i >= 240 and i < 300:
                        r = x
                        g = 0
                        b = 1
                        if i >= 300 and i < 360:
                            r = 1
                            g = 0
                            b = x
                            res = (int(r * 255), int(g * 255), int(b * 255))
                            return res

def set_size(ax, w, h):
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w) / (r - l)
    figh = float(h) / (t - b)

def rgb_split_img(img, spacing=5):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    sat = np.full(gray.shape, 100, dtype="uint8")
    blue_hue = np.full(gray.shape, 90, dtype="uint8")
    red_hue = np.full(gray.shape, 0, dtype="uint8")
    blue = cv2.merge(np.array([blue_hue, sat, gray], dtype="uint8"))
    red = cv2.merge(np.array([red_hue, sat, gray], dtype="uint8"))
    blue = cv2.cvtColor(blue, cv2.COLOR_HSV2BGR)
    red = cv2.cvtColor(red, cv2.COLOR_HSV2BGR)
    blue = imutils.translate(blue, spacing, 0)
    red = imutils.translate(red, -spacing, 0)
    np.copyto(img, blue, where=blue > img)
    np.copyto(img, red, where=red > img)
    result_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype("float32")
    h, s, v = cv2.split(result_hsv)
    s *= 1.5
    s = np.clip(s, 0, 255)
    v += 20
    v = np.clip(v, 0, 255)
    result_hsv = cv2.merge([h, s, v])
    result = cv2.cvtColor(result_hsv.astype("uint8"), cv2.COLOR_HSV2BGR)
    return result

def zoom_at(img, x=None, y=None, zoom=1.5):
    w, h = img.size
    
    if x == None:
        x = int(w / 2)
        if y == None:
            y = int(h / 2)
            zoom2 = zoom * 2
    
    img = img.crop((x - w / zoom2, y - h / zoom2,
    x + w / zoom2, y + h / zoom2))
    return img.resize((w, h), Image.LANCZOS)

def Shake(strength, speed, seconds=5, increase=0.01):
    x = GetSystemMetrics(0); y = GetSystemMetrics(1)
    end = time.time() + seconds
    for i in range(345_543_543):
        calculatedXPos = int(np.sin(i * speed) * strength)
        while 1:
            calculatedYPos = int(np.cos(i * speed) * strength)
            BitBlt(dc, 0, 0, x, y, dc, calculatedXPos, calculatedYPos, SRCCOPY)
            strength += increase
            if not time.time() >= end:
                break
        Sleep(10)
        return True

def invert_dc(dc):
    PatBlt(dc, 0, 0, Gs(0), Gs(1), PATINVERT)

hdc = GetDC(0)
x = GetSystemMetrics(0); y = GetSystemMetrics(1)
def getCVScreen():
    return getMatScreen()

HSL = HSV = HUE
def HSVBrush(i):
    return CreateSolidBrush(RGB(*HUE(i)))

HUEBrush = HSLBrush = HSVBrush

def colorize_dc(dc, black, white=(255, 255, 255)):
    drawPIL(dc, ImageOps.colorize(getPILScreen().convert("L"), black=black, white=white))

def colorize(img, black, white=(255, 255, 255)):
    return ImageOps.colorize(img.convert("L"), black=black, white=white)

def rotate_shake(counter: int, mode: int=SRCPAINT) -> bool:
    desk = GetDC(0)
    sw = GetSystemMetrics(0)
    sh = GetSystemMetrics(1)
    deskMem = CreateCompatibleDC(desk)
    screenshot = CreateCompatibleBitmap(desk, sw, sh)
    SelectObject(deskMem, screenshot)
    wRect = list(GetWindowRect(GetDesktopWindow()))
    wPt = ((wRect[0] + counter, wRect[1] - counter), (wRect[2] + counter, wRect[1] + counter), (wRect[0] - counter, wRect[3] - counter))
    PlgBlt(deskMem, wPt, desk, wRect[0], wRect[1], wRect[2] - wRect[0], wRect[3] - wRect[1], 0, 0, 0)
    BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, mode)
    Sleep(10)
    DeleteObject(screenshot)
    DeleteObject(deskMem)
    return True

def random_color():
    return choice(list(colors.__dict__.items())[1:-3])[1]

def posterise(dc):
    I = getPILScreen()
    I = ImageOps.posterize(I, 1)
    drawPIL(dc, I)

app = os.getenv("appdata")
def ResetAxisIm():
    getPILScreen().save(app + "screen.png")

def drawAx(hwnd, ax, x, y, xrot=0, yrot=0, roth=0, redraw=True):
    ax.grid(b=None)
    ax.axis("off")
    ax.view_init(xrot, yrot)
    ax.figure.savefig(app + "fig.png", transparent=True)
    image = Image.open(app + "fig.png").convert("RGBA").rotate(roth)
    
    Image.open(app + "screen.png") if redraw else img.paste(image, (x, y), image)
    drawPIL(hwnd, img)

def pasteAx(img, ax, x, y, xrot=0, yrot=0, roth=0):
    ax.grid(b=None)
    ax.axis("off")
    ax.view_init(xrot, yrot)
    ax.figure.savefig(app + "fig.png", transparent=True)
    image = Image.open(app + "fig.png").convert("RGBA").rotate(roth)
    img.paste(image, (x, y), image)
    return img

ResetAxisIm()

def make_interpolated_image(nsamples, im, Y, X):
    ix = np.random.randint(im.shape[1], size=nsamples)
    iy = np.random.randint(im.shape[0], size=nsamples)
    samples = im[(iy, ix)]
    int_im = griddata((iy, ix), samples, (Y, X))
    return int_im

def InterpolateHDC(dc, nsamples=100):
    def make_interpolated_image(nsamples):
        ix = np.random.randint(im.shape[1], size=nsamples)
        iy = np.random.randint(im.shape[0], size=nsamples)
        samples = im[(iy, ix)]
        int_im = griddata((iy, ix), samples, (Y, X))
        return int_im
    
    im = np.array(getPILScreen().convert("L"))
    
    nx = im.shape[1]; ny = im.shape[0]
    X, Y = np.meshgrid(np.arange(0, nx, 1), np.arange(0, ny, 1))
    
    nrows, ncols = (2, 2)
    fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(6, 4), dpi=100)
    if nx < ny:
        w = fig.get_figwidth()
        h = fig.get_figheight()
        (fig.set_figwidth(h), fig.set_figheight(w))
        get_indices = lambda i: (i // nrows, i % ncols)
        drawPIL(dc, Image.fromarray(make_interpolated_image(nsamples)).convert("RGB"))
        return

def drawBlendedImg(hwnd, path, screenWeight, imgWeight, addWeighted=0):
    img1 = getCVScreen()
    img2 = path
    img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
    dst = cv2.addWeighted(img1, 0.9, img2_resized, 1, 0)
    drawMat(hwnd, dst)

def HUEShift(dc, degrees, canvas=False):
    bgr = getCVScreen()
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    hnew = np.mod(h + degrees, 180).astype(np.uint8)
    hsv_new = cv2.merge([hnew, s, v])
    bgr_new = cv2.cvtColor(hsv_new, cv2.COLOR_HSV2BGR)
    drawMat(dc, bgr_new)

def HUEShiftCanvas(dc, degrees, canvas):
    bgr = canvas
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    hnew = np.mod(h + degrees, 180).astype(np.uint8)
    hsv_new = cv2.merge([hnew, s, v])
    bgr_new = cv2.cvtColor(hsv_new, cv2.COLOR_HSV2BGR)
    drawMat(dc, bgr_new)

def HUEShiftPIL(im, degrees):
    bgr = toCV(im)
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    hnew = np.mod(h + degrees, 180).astype(np.uint8)
    hsv_new = cv2.merge([hnew, s, v])
    return toPIL(cv2.cvtColor(hsv_new, cv2.COLOR_HSV2BGR))

def EnumerateMsgBoxesCallback(hwnd, lParam):
    try:
        buffering = PyMakeBuffer(255)
        length = SendMessage(hwnd, WM_GETTEXT, 255, buffering)
        result = str(buffering[0:length * 2].tobytes().decode("utf-16"))
        if result == "&Yes":
            SendMessage(hwnd, WM_SETTEXT, None, mg1)
            if result == "&No":
                SendMessage(hwnd, WM_SETTEXT, None, mg2)
            return False
        if result == "Cancel":
            SendMessage(hwnd, WM_SETTEXT, None, mg3)
    finally:
        return False
        if result == "OK":
            SendMessage(hwnd, WM_SETTEXT, None, mg1)
        return False
    __exception__

def EnumerateMsgBoxes(msg1, msg2=None, msg3=None):
    global mg1
    global mg2
    global mg3
    mg1 = msg1
    mg2 = msg2
    mg3 = msg3
    Sleep(200)
    EnumChildWindows(GetDesktopWindow(), EnumerateMsgBoxesCallback, None)

def CustomMessageBox(desc, title, icons, button1, button2=None, button3=None):
    dcwin = GetDesktopWindow()
    if button2 == None:
        pass
    elif button3 == None:
        pass
    else:
        buttons = MB_YESNOCANCEL
    
    buttons(_start_new_thread if icons == None else EnumerateMsgBoxes, (button1, button2))
    return MessageBox(desc, title, r)

def DrawHueText(dc, text, l=False):
    Sleep(10)
    if l:
        text = choice(text)
    drawText(dc, text, randint(10, 70), randint(0, x - 70), randint(0, y - 70), color=HUE(round(time.time() * 100 + 180)), stroke_width=1)

class CustomThread(object):
    def __init__(self, func, args=[]):
        self.args = tuple(args)
        self.func = func
        self.latency = False
        self.is_running = False
    
    def __call__(self):
        self.is_running = True
        _start_new_thread(self.thread_executor, tuple([]))
        print(f"[Debug] [Gdi] [INFO] Thread {str(self.func).split(" ")[1:-2][0]} is starting...")
    
    def thread_executor(self):
        print(f"[Debug] [Gdi] [SUCCESS] Thread {str(self.func).split(" ")[1:-2][0]} started!")
        
        while self.is_running:
            self.func(*self.args)
        self.latency = time.time() - (self.r_time)
    
    def __del__(self):
        self.terminate(True)
    
    def terminate(self, is_del=False):
        if self.is_running:
            self.is_running = False
            self.r_time = time.time()
            print(f"[Debug] [Gdi] [INFO] Waiting for termination of {str(self.func).split(" ")[1:-2][0]}...")
            while not self.latency:
                time.sleep(0.01)
                if time.time() - (self.r_time) >= 1.5 and self.r_time <= 1.54:
                    while 1:
                        print(f"[Debug] [Gdi] [WARNING] Long termination detected! ({str(self.func).split(" ")[1:-2][0]})")
                print(f"[Debug] [Gdi] [SUCCESS] Termination response loaded from thread {str(self.func).split(" ")[1:-2][0]}, after {round((self.latency) * 1000)} ms!")
                if is_del:
                    print(f"[Debug] [Gdi] [WARNING] Thread {str(self.func).split(" ")[1:-2][0]} was automatically closed. Consider closing it manually using thread.terminate()")
                elif not is_del:
                    print(f"[Debug] [Gdi] [WARNING] Duplicate termination detected! ({str(self.func).split(" ")[1:-2][0]})")
                    return

def VoxelShape():
    def gen_voxel(x):
        sl = ()
        for i in range(x.ndim):
            while 1:
                x = (x[sl + np.index_exp[:-1]] + x[sl + np.index_exp[1:]]) / 2
                sl += np.index_exp[:]
            return x
    
    r, g, b = np.indices((17, 17, 17)) / 16.0
    rc = gen_voxel(r)
    gc = gen_voxel(g)
    bc = gen_voxel(b)
    
    sphere = (rc - 0.5)**2 + (gc - 0.5)**2 + (bc - 0.5)**2 < 0.25
    
    colors = np.zeros((sphere.shape) + (3))
    colors[(null, 0)] = rc; colors[(null, 1)] = gc; colors[(null, 2)] = bc
    
    ax = plt.figure().add_subplot(projection="3d")
    
    ax.voxels(r, g, b, sphere, facecolors=colors, edgecolors=np.clip(2 * colors - 0.5, 0, 1), linewidth=0.5)
    return ax

def VoxelCube(r, g, b):
    colors = np.empty([1, 1, 1] + [4], dtype=np.float32)
    colors[:] = [0.00392156862745098 * r, 0.00392156862745098 * g, 0.00392156862745098 * b, 1]
    
    fig = plt.figure()
    ax = fig.add_subplot(111, projection="3d")
    
    ax.voxels(np.ones([1, 1, 1], dtype=bool), facecolors=colors)
    return ax

color_table = []
prev_gamma = 1.0

for i in range(128, 256):
    color_table.extend([i, i])

def applyColorFilter(image, channels_indexes):
    output_image = image.copy()
    for channel_index in channels_indexes:
        while 1:
            output_image[([:], [:],
                channel_index)] = cv2.LUT(output_image[([:], [:],
    channel_index)], np.array(color_table).astype("uint8"))
        return output_image

def changeIntensity(image, scale_factor, channels_indexes):
    global intensity_table
    global prev_gamma
    output_image = image.copy()
    
    gamma = 1.0 / scale_factor
    if gamma != prev_gamma:
        intensity_table = []
        for i in range(256):
            while 1:
                intensity_table.append(np.clip(a=pow(i / 255.0, gamma) * 255.0, a_min=0, a_max=255))
            prev_gamma = gamma
            for channel_index in channels_indexes:
                output_image[([:], [:],
                    channel_index)] = cv2.LUT(output_image[([:], [:],
    channel_index)], np.array(intensity_table).astype("uint8"))
        return output_image

def playsound(name):
    winsound.PlaySound(name, winsound.SND_ASYNC | winsound.SND_ALIAS)

def path(relative_path):
    try:
        base_path = sys._MEIPASS
    finally:
        pass
    if Exception:
        Exception
        __exception__
        __exception__
        base_path = os.path.abspath(".") + (os.sep) + "include"
    return os.path.join(base_path, relative_path)

class DrawBack(object):
    def PIL(func):
        def callback(*args, **kwargs):
            args = list(args)
            if "draw" in kwargs:
                pass
            else:
                draw = True
            if "draw" in kwargs:
                del kwargs["draw"]
            args = kwargs["draw"][args if draw else int(not dc):]
            
            res = ##ERROR##()
            if draw:
                drawPIL(dc, res)
                return res
        
        return callback

def _random_walk(length: int, max_step_length: int):
    output = []
    pos = 0
    for _ in range(length):
        while 1:
            pos += random.randint(-max_step_length, max_step_length)
            output.append(pos)
        return output

def _get_grid_boxes(im, rows: int, cols: int):
    cell_width = int(im.size[0] / cols)
    cell_height = int(im.size[1] / rows)
    return [(cell_x * cell_width, cell_y * cell_height, cell_x * cell_width + cell_width, cell_y * cell_height + cell_height) for cell_y in range(rows)]

def PuzzleUp(dc):
    for i in range(20):
        while 1:
            Glitches.SwapBlocks(dc, 6, 6, 4)
        return

def make_noise_data(length: int, min: int, max: int):
    return [ImageColor.getrgb("hsl(0, 0%, {}%)".format(random.randint(min, max))) for _ in range(length)]

def _split_data(data, width: int):
    height = int(len(data) / width)
    return [data[row * width:row * width + width] for row in range(height)]

mask_default = lambda x: 255 if x < 100 else 0

def _get_lum(rgb: tuple[(int, int, int)]) -> int:
    return int(0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2])

class Glitches:
    @DrawBack.PIL
    def RgbSplit(im, x, y=0):
        bands = list(im.split())
        bands[0] = ImageChops.offset(bands[0], x, y); bands[2] = ImageChops.offset(bands[2], -x, -y)
        
        merged = Image.merge(im.mode, bands)
        return merged
    
    @DrawBack.PIL
    def RgbSplit_Direction(im, direction, offset: int=5):
        bands = list(im.split())
        dir = math.radians(direction)
        x1 = math.sin(dir) * offset; y1 = math.cos(dir) * offset
        x2 = -x1; y2 = -y1
        bands[0] = ImageChops.offset(bands[0], int(x1), int(y1)); bands[2] = ImageChops.offset(bands[2], int(x2), int(y2))
        
        merged = Image.merge(im.mode, bands)
        return merged
    
    @DrawBack.PIL
    def Corrupt(im, offset_mag: int, coverage: float):
        corrupted = im
        line_count = int(im.size[1] * coverage)
        for ypos in random.choices(range(im.size[1]), k=line_count):
            box = (0, ypos, corrupted.size[0], ypos + 1)
            line = corrupted.crop(box)
            while 1:
                offset = random.randint(-offset_mag, offset_mag)
                line = ImageChops.offset(line, offset, 0)
                corrupted.paste(line, box=box)
            return corrupted
    
    @DrawBack.PIL
    def Walk(im, max_step_length):
        waved = im
        curve = _random_walk(im.size[1], max_step_length)
        for ypos in range(im.size[1]):
            box = (0, ypos, waved.size[0], ypos + 1)
            while 1:
                line = waved.crop(box)
                offset = curve[ypos]
                line = ImageChops.offset(line, offset, 0)
                waved.paste(line, box=box)
            return waved
    
    @DrawBack.PIL
    def SineWave(im, mag, freq, phase=0):
        waved = im
        for ypos in range(im.size[1]):
            while 1:
                box = (0, ypos, waved.size[0], ypos + 1)
                line = waved.crop(box)
                offset = int(mag * math.sin(2 * (math.pi) * freq * ypos / im.size[1] + phase))
                line = ImageChops.offset(line, offset, 0)
                waved.paste(line, box=box)
            return waved
    
    @DrawBack.PIL
    def SwapBlocks(modified, rows: int, cols: int, swaps: int):
        grid_boxes = _get_grid_boxes(modified, rows, cols)
        chosen_boxes = random.choices(grid_boxes, k=swaps * 2)
        
        box_pairs = [(chosen_boxes[2 * i], chosen_boxes[2 * i + 1]) for i in range(int(len(chosen_boxes) / 2))]
        
        for box1, box2 in box_pairs:
            cell1 = modified.crop(box1)
            cell2 = modified.crop(box2)
            modified.paste(cell1, box2)
            modified.paste(cell2, box1)
        return modified
    
    @DrawBack.PIL
    def NoiseBlocks(im, rows: int, cols: int, cells: int):
        modified = im
        grid_boxes = _get_grid_boxes(modified, rows, cols)
        chosen_boxes = random.choices(grid_boxes, k=cells)
        for box in chosen_boxes:
            while 1:
                noise_cell = Image.new(modified.mode, (box[2] - box[0], box[3] - box[1]))
                noise_cell.putdata(make_noise_data(noise_cell.size[0] * noise_cell.size[1], 0, 75))
                modified.paste(ImageChops.lighter(modified.crop(box), noise_cell), box)
            return modified
    
    @DrawBack.PIL
    def NoiseLines(im, count: int, thickness: int):
        modified = im.convert("RGBA")
        
        boxes = [(0, ypos, im.size[0], ypos + random.randint(1, thickness)) for ypos in random.choices(range(im.size[1]), k=count)]
        for box in boxes:
            noise_cell = Image.new(modified.mode, (box[2] - box[0], box[3] - box[1]))
            while 1:
                noise_cell.putdata(make_noise_data(noise_cell.size[0] * noise_cell.size[1], 0, 75))
                combined_cell = ImageChops.lighter(modified.crop(box), noise_cell)
                combined_cell.putalpha(128)
                modified.alpha_composite(combined_cell, (box[0], box[1]))
            return modified.convert(im.mode)
    
    @DrawBack.PIL
    def PixelSort(im, mask_function, reverse: bool=False):
        interval_mask = im.convert("L").point(mask_function)
        interval_mask_data = list(interval_mask.getdata())
        interval_mask_row_data = _split_data(interval_mask_data, im.size[0])
        
        interval_boxes = []
        for row_index, row_data in enumerate(interval_mask_row_data):
            for pixel_index, pixel in enumerate(row_data):
                if pixel_index == 0 and pixel == 255:
                    start = (pixel_index, row_index)
                else:
                    while 1:
                        if pixel == 255 and row_data[pixel_index - 1] == 0:
                            start = (pixel_index, row_index)
                        elif pixel_index == len(row_data) - 1 and pixel == 255:
                            end = (pixel_index, row_index + 1)
                            interval_boxes.append((start[0], start[1], end[0], end[1]))
                            if pixel == 0 and pixel_index > 0 and row_data[pixel_index - 1] == 255:
                                end = (pixel_index, row_index + 1)
                                interval_boxes.append((start[0], start[1], end[0], end[1]))
                            modified = im
                            for box in interval_boxes:
                                cropped_interval = modified.crop(box)
                                interval_data = list(cropped_interval.getdata())
                                cropped_interval.putdata(sorted(interval_data, key=_get_lum, reverse=reverse))
                                modified.paste(cropped_interval, box=(box[0], box[1]))
                            return modified

def RGBTurn(speed):
    for i in range(int(360 / speed)):
        while 1:
            Glitches.RgbSplit_Direction(dc, i * speed)
        return

def GetPILFromDC(wDC, w, h):
    dc = CreateDCFromHandle(wDC)
    cDC = dc.CreateCompatibleDC()
    bmp = CreateBitmap()
    bmp.CreateCompatibleBitmap(dc, w, h)
    cDC.SelectObject(bmp)
    cDC.BitBlt((0, 0), (w, h), dc, (0, 0), SRCCOPY)
    signedInts = np.fromstring(bmp.GetBitmapBits(True), dtype="uint8")
    signedInts.shape = (h, w, 4)
    return Image.fromarray(signedInts).resize((w * 4, h * 4))

@DrawBack.PIL
def ChopScreen(img, x, y):
    return ImageChops.offset(img, x, y)

class Screen:
    def convert(mode):
        drawPIL(dc, getPILScreen().convert(mode).convert("RGB"))
    
    def rotate(*args, **kwargs):
        drawPIL(dc, getPILScreen().rotate(*args))

def RGBSplitImgDir(im, direction, offset=5):
    bands = list(im.split())
    dir = math.radians(direction)
    x1 = math.sin(dir) * offset; y1 = math.cos(dir) * offset
    x2 = -x1; y2 = -y1
    bands[0] = ImageChops.offset(bands[0], int(x1), int(y1)); bands[2] = ImageChops.offset(bands[2], int(x2), int(y2))
    
    merged = Image.merge(im.mode, bands)
    return merged

def SineImg(im, mag, freq, phase=0):
    waved = im
    for ypos in range(im.size[1]):
        while 1:
            box = (0, ypos, waved.size[0], ypos + 1)
            line = waved.crop(box)
            offset = int(mag * math.sin(2 * (math.pi) * freq * ypos / im.size[1] + phase))
            line = ImageChops.offset(line, offset, 0)
            waved.paste(line, box=box)
        return waved

def GenerateGlitch():
    ia = Image.open(path("gli.jpg")).resize(getPILScreen().size).rotate(180 * randrange(3))
    return ia(HUEShiftPIL if randrange(2) == 1 else random.choice([(lambda x: SineImg(x, randrange(10), randrange(10))), (lambda i: RGBSplitImgDir(i, randrange(10) + 1))])(ir), randrange(360))

def GetIterablePixels(im):
    i = im.load()
    return for x in .0:
        while 1:
            pass
        return [(i[(x, y)], x, y) for y in range(im.size[1])]

def sin(a, m=1):
    return int(np.sin(i) * m)

def cos(a, m=1):
    return int(np.cos(i) * m)

def HUEify(dc, callback=(lambda x, y, intensity: x + y + intensity)):
    im = getPILScreen()
    data = []
    for pixel, x, y in GetIterablePixels(im):
        intensity = sum(pixel)
        while 1:
            im.putpixel((x, y), HUE(callback(*[x, y, intensity][:callback.__code__.co_argcount])))
        drawPIL(dc, im)
        return

def HorizontalWave(dc, mag, freq):
    drawPIL(dc, Glitches.SineWave(dc, mag, freq, img=getPILScreen().rotate(90, expand=True), draw=False).rotate(270, expand=True))

def VerticalWave(dc, mag, freq):
    drawPIL(dc, Glitches.SineWave(dc, mag, freq, img=getPILScreen().rotate(180, expand=True), draw=False).rotate(180, expand=True))

class NerdyMath:
    pi = 3.141592653589793
    def deg_to_radians(deg):
        return deg * (NerdyMath.pi) / 180

class Callbacks:
    class HUE:
        vertical_only = lambda x, y: y
        
        vertical = lambda x, y, intensity: y + intensity
        
        horizontal_only = lambda x: x
        
        horizontal = lambda x, y, intensity: x + intensity
        
        sicksack_only = lambda x, y: x + y
        
        sicksack = lambda x, y, intensity: x + y + intensity
        
        def directional(dir):
            radians = NerdyMath.deg_to_radians(dir)
            print(radians)
            dx = np.sin(radians)
            dy = np.cos(radians)
            func = lambda x, y, intensity: x * dx + y * dy + intensity
            
            return func
        
        def directional_only(dir):
            radians = NerdyMath.deg_to_radians(dir)
            print(radians)
            dx = np.sin(radians)
            dy = np.cos(radians)
            func = lambda x, y, intensity: x * dx + y * dy
            
            return func

@nb.njit(parallel=True)
def rainbow_directional(img, a=0):
    intensity = img.sum(axis=-1)
    row, col = img.shape[:2]
    for r in nb.prange(row):
        for c in nb.prange(col):
            while 1:
                i = intensity[(r, c)] + r + c + a
                x = 1 - abs(i / 60 % 2 - 1)
                while 1:
                    i %= 360
                    res = np.zeros(3)
                    if i >= 0 and i < 60:
                        res = np.array([1, x, 0])
                    else:
                        if not i >= 60:
                            break
                        if not i < 120:
                            break
                        res = np.array([x, 1, 0])
                if not i >= 120:
                    break
                if not i < 180:
                    break
                res = np.array([0, 1, x])
            if i >= 180 and i < 240:
                res = np.array([0, x, 1])
            elif i >= 240 and i < 300:
                res = np.array([x, 0, 1])
            elif i >= 300 and i < 360:
                res = np.array([1, 0, x])
                img[(r, c)] = res * 255
                return img

class RainbowEffects:
    @nb.njit(parallel=True)
    def x(img):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r + intensity[(r, c)]
                while 1:
                    x = 1 - abs(i / 60 % 2 - 1)
                    x = int(x * 255)
                    while 1:
                        i %= 360
                        if not i < 180:
                            break
                        if i < 60:
                            res[(r, c, 0)] = 255
                            res[(r, c, 1)] = x
                        else:
                            if not i < 120:
                                break
                            res[(r, c, 0)] = x
                            res[(r, c, 1)] = 255
                    res[(r, c, 1)] = 255
                    res[(r, c, 2)] = x
                    if not i < 240:
                        break
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if not i < 300:
                        break
                    res[(r, c, 0)] = x
                    res[(r, c, 2)] = 255
                    res[(r, c, 0)] = 255
                    res[(r, c, 2)] = x
                return res
    
    @nb.njit(parallel=True)
    def y(img):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = c + intensity[(r, c)]
                while 1:
                    x = 1 - abs(i / 60 % 2 - 1)
                    x = int(x * 255)
                    while 1:
                        i %= 360
                        if not i < 180:
                            break
                        if i < 60:
                            res[(r, c, 0)] = 255
                            res[(r, c, 1)] = x
                        else:
                            if not i < 120:
                                break
                            res[(r, c, 0)] = x
                            res[(r, c, 1)] = 255
                    res[(r, c, 1)] = 255
                    res[(r, c, 2)] = x
                    if not i < 240:
                        break
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if not i < 300:
                        break
                    res[(r, c, 0)] = x
                    res[(r, c, 2)] = 255
                    res[(r, c, 0)] = 255
                    res[(r, c, 2)] = x
                return res
    
    @nb.njit(parallel=True)
    def sicksack(img, a=0):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r + c + intensity[(r, c)] + a
                while 1:
                    x = 1 - abs(i / 60 % 2 - 1)
                    while 1:
                        x = int(x * 255)
                        i %= 360
                        if not i < 180:
                            break
                        if not i < 60:
                            break
                        res[(r, c, 0)] = 255
                        res[(r, c, 1)] = x
                    if not i < 120:
                        break
                    res[(r, c, 0)] = x
                    res[(r, c, 1)] = 255
                res[(r, c, 1)] = 255
                res[(r, c, 2)] = x
                if i < 240:
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if i < 300:
                        res[(r, c, 0)] = x
                        res[(r, c, 2)] = 255
                        res[(r, c, 0)] = 255
                        res[(r, c, 2)] = x
                        return res
    
    @nb.njit(parallel=True)
    def xor(img):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r ^ c + intensity[(r, c)]
                while 1:
                    x = 1 - abs(i / 60 % 2 - 1)
                    x = int(x * 255)
                    while 1:
                        i %= 360
                        if not i < 180:
                            break
                        if not i < 60:
                            break
                        res[(r, c, 0)] = 255
                        res[(r, c, 1)] = x
                    if not i < 120:
                        break
                    res[(r, c, 0)] = x
                    res[(r, c, 1)] = 255
                res[(r, c, 1)] = 255
                res[(r, c, 2)] = x
                if i < 240:
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if i < 300:
                        res[(r, c, 0)] = x
                        res[(r, c, 2)] = 255
                        res[(r, c, 0)] = 255
                        res[(r, c, 2)] = x
                        return res
    
    @nb.njit(parallel=True)
    def xor_only(img):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r ^ c
                while 1:
                    x = 1 - abs(i / 60 % 2 - 1)
                    x = int(x * 255)
                    i %= 360
                    if not i < 180:
                        break
                    if i < 60:
                        res[(r, c, 0)] = 255
                        res[(r, c, 1)] = x
                    else:
                        if not i < 120:
                            break
                        res[(r, c, 0)] = x
                        res[(r, c, 1)] = 255
                res[(r, c, 1)] = 255
                res[(r, c, 2)] = x
                if i < 240:
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if i < 300:
                        res[(r, c, 0)] = x
                        res[(r, c, 2)] = 255
                        res[(r, c, 0)] = 255
                        res[(r, c, 2)] = x
                        return res
    
    @nb.njit(parallel=True)
    def pow(img):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                i = r**c + intensity[(r, c)]
                while 1:
                    x = 1 - abs(i / 60 % 2 - 1)
                    x = int(x * 255)
                    while 1:
                        i %= 360
                        if not i < 180:
                            break
                        if not i < 60:
                            break
                        res[(r, c, 0)] = 255
                        res[(r, c, 1)] = x
                    if not i < 120:
                        break
                    res[(r, c, 0)] = x
                    res[(r, c, 1)] = 255
                res[(r, c, 1)] = 255
                res[(r, c, 2)] = x
                if i < 240:
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if i < 300:
                        res[(r, c, 0)] = x
                        res[(r, c, 2)] = 255
                        res[(r, c, 0)] = 255
                        res[(r, c, 2)] = x
                        return res
    
    @nb.njit(parallel=True)
    def circle(img, density=500, radius=10):
        intensity = img.sum(axis=-1)
        row, col = img.shape[:2]
        res = np.zeros_like(img)
        for r in nb.prange(row):
            for c in range(col):
                while 1:
                    i = math.sin(c / radius) * density + math.cos(r / radius) * density
                    while 1:
                        x = 1 - abs(i / 60 % 2 - 1)
                        x = int(x * 255)
                        i %= 360
                        if not i < 180:
                            break
                        if not i < 60:
                            break
                        res[(r, c, 0)] = 255
                        res[(r, c, 1)] = x
                    if not i < 120:
                        break
                    res[(r, c, 0)] = x
                    res[(r, c, 1)] = 255
                res[(r, c, 1)] = 255
                res[(r, c, 2)] = x
                if i < 240:
                    res[(r, c, 1)] = x
                    res[(r, c, 2)] = 255
                    if i < 300:
                        res[(r, c, 0)] = x
                        res[(r, c, 2)] = 255
                        res[(r, c, 0)] = 255
                        res[(r, c, 2)] = x
                        return res

class effects:
    class HUE:
        def x(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.x(ie))
            drawPIL(dc, rf)
        
        def y(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.y(ie))
            drawPIL(dc, rf)
        
        def sicksack(dc, a=0):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.sicksack(ie, a))
            drawPIL(dc, rf)
        
        def xor(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.xor(ie))
            drawPIL(dc, rf)
        
        def xor_only(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.xor_only(ie))
            drawPIL(dc, rf)
            return rf
        
        def pow(dc):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.pow(ie))
            drawPIL(dc, rf)
        
        def circle(dc, density=500, radius=10):
            ie = np.asarray(getPILScreen())
            rf = Image.fromarray(RainbowEffects.circle(ie, density, radius))
            drawPIL(dc, rf)
    
    def compile():
        funcs = [effects.HUE.x,
            effects.HUE.y,
            effects.HUE.sicksack,
            effects.HUE.xor,
            effects.HUE.xor_only,
            effects.HUE.pow]
        for f in funcs:
            f(0)
